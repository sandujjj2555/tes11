# Step 1: Run the Telegram bot script (telegram_bot.py) in the main terminal
echo "Running Telegram bot script (telegram_bot.py)..."
python3 telegram_bot.py  # This will run the Telegram bot script in the main terminal

# Done
echo "Telegram bot script is running!"