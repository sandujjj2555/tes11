import asyncio
import os
from telegram import Bot
import glob

# Replace with your bot's tokens and chat IDs
BOT_TOKENS = ['7762778610:AAEAHB_dk--9kD20MmFbCGW3mgel5DZqGNo', '7881736423:AAEEfBkKQdqZXxN_DpeVUbSI7Y-0WtO1jzg', '7942753654:AAHu69RyY4c3JgK49dJn72-SONwECe4WOVA']
CHAT_IDS = ['1346013346', '1320634531', '7595636514']

async def send_message(bot, chat_id, message):
    await bot.send_message(chat_id=chat_id, text=message)

async def send_file(bot, chat_id, file_path):
    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            await bot.send_document(chat_id=chat_id, document=file)
    else:
        await send_message(bot, chat_id, f"File {file_path} does not exist.")

def get_latest_continue_file():
    # Get the latest continue file (e.g., *.txt)
    files = glob.glob("*.txt")
    if not files:
        return None
    # Sort by modification time (most recent first)
    files.sort(key=os.path.getmtime, reverse=True)
    return files[0]  # Return the most recent file

async def send_files_periodically():
    bots = [Bot(token=token) for token in BOT_TOKENS]
    
    while True:
        # Find the latest continue file
        latest_file = get_latest_continue_file()

        if latest_file:
            for bot, chat_id in zip(bots, CHAT_IDS):
                # Send message to each bot
                await send_message(bot, chat_id, f"Sending the files out.txt and {latest_file}")
                
                # Send the files to each bot
                await send_file(bot, chat_id, 'out.txt')
                await send_file(bot, chat_id, latest_file)
        else:
            for bot, chat_id in zip(bots, CHAT_IDS):
                await send_message(bot, chat_id, "No continue file found!")

        # Wait for 5 minutes
        wait_time = 5 * 60  # 300 seconds
        await asyncio.sleep(wait_time)

# Run the asynchronous function in an existing event loop
loop = asyncio.get_event_loop()
if loop.is_running():
    # If the loop is already running (e.g., in Jupyter Notebook), use ensure_future
    asyncio.ensure_future(send_files_periodically())
else:
    # If no loop is running, use run
    loop.run_until_complete(send_files_periodically())

